import React from 'react';

const PokemonNameList = (props) => {
    return(
        <li className="m-4">{props.name}</li>
    )
}
export default PokemonNameList;