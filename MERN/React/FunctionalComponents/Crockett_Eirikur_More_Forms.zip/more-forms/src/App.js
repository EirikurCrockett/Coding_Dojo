import '../node_modules/bootstrap/dist/css/bootstrap.css';
import SimpleUserForm from './components/SimpleUserForm';

function App() {
  return (
    <div className="border p-3 w-50 mx-auto my-3 ">
      <SimpleUserForm/>
    </div>
  );
}

export default App;
