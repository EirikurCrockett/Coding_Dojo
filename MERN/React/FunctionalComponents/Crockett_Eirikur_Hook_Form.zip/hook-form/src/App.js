import './App.css';
import SimpleUserForm from './components/SimpleUserForm';

function App() {
  return (
    <div className="App">
      <SimpleUserForm/>
    </div>
  );
}

export default App;
