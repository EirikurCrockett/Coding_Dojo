import ProductForm from "../components/ProductForm";

const FormPage = (props) => {
    return(
        <div>
            <ProductForm/>
        </div>
    )
}

export default FormPage;