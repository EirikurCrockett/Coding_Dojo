import React from "react";

const Main = (props) => {
    return(
        <div className="text-center m-3 p-3">
            <h1>Welcome to Product Manager</h1>
        </div>
    )
}

export default Main;