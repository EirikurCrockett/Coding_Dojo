print('hello World')

name = 'Eirikur'

print('Hello', name)
print('Hello ' + name)

num = 9

print('hello', num)
print('hello ' + str(num))

food_one = 'buffalo chicken'
food_two = 'chicken teriyaki'

print('I love to eat {} and {}'.format(food_one, food_two))
print(f'I love to eat {food_one} and {food_two}')

age = 24

print("My name is %s and I'm %d" % (name, age))
