from flask import Flask, redirect, render_template, request
app = Flask(__name__)
app.secret_key = 'e8wdzx12dqw856x43as2dqw685'