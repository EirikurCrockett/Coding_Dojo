﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Attach validation error styling to any input that is invalid
$(".input-validation-error").each(function(){
    $(this).addClass("is-invalid");
});

// Write your JavaScript code.
